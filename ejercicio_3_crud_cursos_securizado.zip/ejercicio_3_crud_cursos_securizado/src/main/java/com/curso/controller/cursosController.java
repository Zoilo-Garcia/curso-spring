package com.curso.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.curso.model.Curso;
import com.curso.service.CursoService;

@RestController
public class cursosController {
	
	@Autowired
	CursoService service;
	
	@GetMapping(value="curso/{codCurso}", produces=MediaType.APPLICATION_JSON_VALUE)
	public Curso buscarCurso (@PathVariable ("codCurso") String codCurso) {
		return service.buscarCurso(codCurso);
	}
	
	@GetMapping(value="cursos", produces=MediaType.APPLICATION_JSON_VALUE)
	public List<Curso> cursos () {
		return service.cursos();
	}
	
	@PostMapping(value="curso", consumes=MediaType.APPLICATION_JSON_VALUE, produces=MediaType.APPLICATION_JSON_VALUE)
	public List<Curso> agregar (@RequestBody Curso curso) {
		return service.altaCurso(curso);
	}
	
	@DeleteMapping(value="curso/{codCurso}", produces=MediaType.APPLICATION_JSON_VALUE)
	public List<Curso> eliminar (@PathVariable ("codCurso") String codCurso) {
		return service.eliminarCurso(codCurso);
	}
	
	@PutMapping(value="curso/{codCurso}/{duracion}")
	public void actualizar (@PathVariable("codCurso") String codCurso,  @PathVariable("duracion") int duracion) {
		service.actualizarDuracion(codCurso, duracion);
	}
	
	@GetMapping(value="curso/{preciomin}/{preciomax}", produces=MediaType.APPLICATION_JSON_VALUE)
	public List<Curso> buscarPorPrecio (@PathVariable ("preciomin") int preciomin, @PathVariable ("preciomax") int preciomax) {
		return service.cursosPorPrecio(preciomin, preciomax);
	}
}
