package com.curso.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

import com.curso.model.Curso;
import com.curso.model.Formacion;

@Service
public class FormacionServiceImpl implements FormacionService {
	
	@Autowired
	RestClient restClient;	
	private String url = "http://servicio-cursos/";

	@Override
	public List<Formacion> formaciones() {
		List<Curso> listaCursos = Arrays.asList(getCursos(url + "cursos"));
		List<Formacion> listaFormacion = new ArrayList<>();
		for (Curso curso : listaCursos) {
			Formacion formacion = new Formacion();
			formacion.setCurso(curso.getNombre());
			formacion.setPrecio(curso.getPrecio());
			formacion.setAsignaturas(curso.getDuracion()>=50?10:5);
			listaFormacion.add(formacion);
		}
		return listaFormacion;
	}

	@Override
	public void altaFormacion(Formacion formacion) {
		String codCurso= formacion.getCurso().substring(0, 3)+formacion.getAsignaturas()*10;
		Curso curso = new Curso(codCurso, formacion.getCurso(), formacion.getAsignaturas()*10, formacion.getPrecio());
		List<Curso> listaCursos = Arrays.asList(getCursos(url + "cursos"));
		Boolean existe =false;
		
		for (Curso item : listaCursos) {
			if(item.getNombre().equals(curso.getNombre())) {
				existe= true;
				break;
			}
		}
		
		if(!existe) {			
			agregarCurso(url + "curso", curso);
		}
	}
	
	private Curso[] getCursos(String url){
		return restClient.get()
		.uri(url)
		.retrieve()
		.body(Curso[].class);
	}
	
	private void agregarCurso(String url, Curso curso){
		restClient.post()
		.uri(url)
		.accept(MediaType.APPLICATION_JSON)
		.body(curso)
		.retrieve().toBodilessEntity();
	}	

}
