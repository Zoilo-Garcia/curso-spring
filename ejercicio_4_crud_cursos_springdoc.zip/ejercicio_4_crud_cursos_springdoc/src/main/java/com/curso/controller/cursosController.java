package com.curso.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.curso.model.Curso;
import com.curso.service.CursoService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;

@RestController
public class cursosController {
	
	@Autowired
	CursoService service;
	@Operation(summary ="Busque curso por codigo del curso", description = "Localiza un curso determinado proporcionado en codigo de indetificacion del curso")
	@GetMapping(value="curso/{codCurso}", produces=MediaType.APPLICATION_JSON_VALUE)
	public Curso buscarCurso (@Parameter(description = "Codigo del curso a buscar")@PathVariable ("codCurso") String codCurso) {
		return service.buscarCurso(codCurso);
	}
	
	@Operation(summary ="Consultar el catálogo de cursos", description = "Consultar el catálogo completo de cursos disponibles")
	@GetMapping(value="cursos", produces=MediaType.APPLICATION_JSON_VALUE)
	public List<Curso> cursos () {
		return service.cursos();
	}
	
	@Operation(summary ="Añada un curso al catalogo", description = "Se agrega un nuevo curso al catalogo de cursos y se devuelve el listado actualizado")
	@PostMapping(value="curso", consumes=MediaType.APPLICATION_JSON_VALUE, produces=MediaType.APPLICATION_JSON_VALUE)
	public List<Curso> agregar (@RequestBody Curso curso) {
		return service.altaCurso(curso);
	}
	
	@Operation(summary ="Elimine curso por codigo del curso", description = "Elimine un cusrso determinado proporcionado en codigo de indetificacion del curso y obteniendo el listado actualizado")
	@DeleteMapping(value="curso/{codCurso}", produces=MediaType.APPLICATION_JSON_VALUE)
	public List<Curso> eliminar (@Parameter(description = "Codigo del curso a eliminar")@PathVariable ("codCurso") String codCurso) {
		return service.eliminarCurso(codCurso);
	}
	
	@Operation(summary ="Actualice la duracion de un curso por codigo", description = "Actualice la duracion de un curso determinado proporcionado en codigo de indetificacion del curso")
	@PutMapping(value="curso/{codCurso}/{duracion}")
	public void actualizar (@Parameter(description = "Codigo del curso a actualizar")@PathVariable("codCurso") String codCurso,  @Parameter(description = "Duracion del curso a actualizar")@PathVariable("duracion") int duracion) {
		service.actualizarDuracion(codCurso, duracion);
	}
	
	@Operation(summary ="Consultar el catálogo de cursos entre dos cantidades", description = "Consultar el catálogo de cursos disponibles cuyos precios esten dentro del baremo porporcionado")
	@GetMapping(value="curso/{preciomin}/{preciomax}", produces=MediaType.APPLICATION_JSON_VALUE)
	public List<Curso> buscarPorPrecio (@Parameter(description = "Precio minimo del curso")@PathVariable ("preciomin") int preciomin, @Parameter(description = "Precio minimo del curso")@PathVariable ("preciomax") int preciomax) {
		return service.cursosPorPrecio(preciomin, preciomax);
	}
}
