package com.curso.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.curso.model.Curso;

// se pone el Objeto y el tipo de la primary key
public interface CursosDao extends JpaRepository<Curso, String> {

	List<Curso> findByPrecioBetween(int preciomin, int preciomax);
}
