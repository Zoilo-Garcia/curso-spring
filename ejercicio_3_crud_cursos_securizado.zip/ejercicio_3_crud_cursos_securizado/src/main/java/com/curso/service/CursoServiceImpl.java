package com.curso.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.curso.dao.CursosDao;
import com.curso.model.Curso;

@Service
public class CursoServiceImpl implements CursoService {
	@Autowired
	CursosDao dao;

	@Override
	public List<Curso> cursos() {
		return dao.findAll();
	}

	@Override
	public List<Curso> altaCurso(Curso curso) {
		dao.save(curso);
		return cursos();
	}

	@Override
	public List<Curso> eliminarCurso(String codCurso) {
		dao.deleteById(codCurso);
		return cursos();
	}

	@Override
	public void actualizarDuracion(String codCurso, int duracion) {
		Curso curso = buscarCurso(codCurso);
		curso.setDuracion(duracion);
		dao.save(curso);
	}

	@Override
	public Curso buscarCurso(String codCurso) {
		return dao.findById(codCurso).orElse(null);
	}

	@Override
	public List<Curso> cursosPorPrecio(int preciomin, int preciomax) {			
		return dao.findByPrecioBetween(preciomin, preciomax);
	}
}
