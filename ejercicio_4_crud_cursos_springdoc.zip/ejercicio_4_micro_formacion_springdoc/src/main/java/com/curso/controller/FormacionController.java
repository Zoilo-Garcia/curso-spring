package com.curso.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.curso.model.Formacion;
import com.curso.service.FormacionService;

import io.swagger.v3.oas.annotations.Operation;

@RestController
public class FormacionController {
	
	@Autowired
	FormacionService service;
	
	@Operation(summary ="Consultar el catálogo de formaciones", description = "Consultar el catálogo completo de formaciones disponibles")
	@GetMapping(value="cursos", produces=MediaType.APPLICATION_JSON_VALUE)
	public List<Formacion> cursos(){
		return service.formaciones();
	}
	@Operation(summary ="Agregar una formacion", description = "Agregar una formacion al catálogo completo de formaciones disponibles")
	@PostMapping(value="curso", consumes=MediaType.APPLICATION_JSON_VALUE)
	public void agregar (@RequestBody Formacion formacion) {
		service.altaFormacion(formacion);
	}

}
